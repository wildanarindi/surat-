      <div class="clearfix">

		<div class="alert alert-dismissable alert-success">
			Selamat datang <strong><?php echo $this->session->userdata('admin_nama'); ?></strong> 
		</div>
			
      </div>
